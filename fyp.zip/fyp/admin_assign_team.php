<?php
session_start();
require 'db_connection.php'; // Ensure this file contains your PDO connection
include 'admin_nav.html';

// Check if the user is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Get the report ID from the URL
$report_id = isset($_GET['report_id']) ? (int)$_GET['report_id'] : 0;

// Fetch the report details
$query = "SELECT * FROM reports WHERE id = :report_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':report_id', $report_id);
$stmt->execute();
$report = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if the report exists
if (!$report) {
    echo "Report not found.";
    exit;
}

// Fetch all users with the role of 'maintenance' (or however you define your maintenance team)
$query = "SELECT * FROM users WHERE role = 'maintenance_team'";
$stmt = $db->prepare($query);
$stmt->execute();
$maintenance_users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;

    // Update the report with the selected maintenance user's ID
    $updateQuery = "UPDATE reports SET status = 'assigned', assigned_to = :user_id WHERE id = :report_id";
    $updateStmt = $db->prepare($updateQuery);
    $updateStmt->bindParam(':user_id', $user_id);
    $updateStmt->bindParam(':report_id', $report_id);
    
    if ($updateStmt->execute()) {
        echo "Report assigned to the maintenance user successfully.";
    } else {
        echo "Failed to assign the report.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Maintenance User</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to external CSS file -->
    <style>
        /* Basic Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            padding: 100px;
            background-color: #f7f7f7; /* Light grey background for brightness */
            color: #333; /* Dark grey text for readability */
            font-family: Arial, sans-serif;
        }

        /* Container Styling */
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #ffffff; /* White container background */
            border: 1px solid #ddd; /* Light grey border */
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow */
        }

        /* Header Styling */
        h2 {
            font-size: 24px;
            color: #333; /* Dark grey for header text */
            text-align: center;
            margin-bottom: 15px;
        }

        /* Paragraph Styling */
        p {
            font-size: 16px;
            color: #555; /* Medium grey for paragraph text */
            margin-bottom: 10px;
        }

        /* Form Styling */
        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        /* Label Styling */
        label {
            font-size: 16px;
            color: #444; /* Slightly darker grey for labels */
        }

        /* Select Dropdown Styling */
        select {
            padding: 10px;
            font-size: 16px;
            color: #333; /* Dark text color */
            border-radius: 4px;
            border: 1px solid #ccc; /* Light grey border */
            background-color: #ffffff; /* White background */
            transition: border-color 0.3s;
        }
        select:focus {
            border-color: #666; /* Darker grey on focus */
            outline: none;
        }

        /* Button Styling */
        .button {
            padding: 12px;
            font-size: 16px;
            color: #ffffff; /* White text */
            background-color: #333333; /* Dark grey button */
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .button:hover {
            background-color: #555555; /* Medium grey on hover */
        }

        /* Success/Error Message Styling */
        .message {
            text-align: center;
            margin-top: 15px;
            font-size: 16px;
            color: #28a745; /* Light green for success */
        }
        .error {
            color: #dc3545; /* Red for error */
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Assign Maintenance User to Report: <?= htmlspecialchars($report['id']) ?></h2>
        <p><strong>Report Title:</strong> <?= htmlspecialchars($report['title']) ?></p>
        <p><strong>Status:</strong> <?= htmlspecialchars($report['status']) ?></p>

        <!-- Form to Assign Maintenance User -->
        <form method="POST">
            <label for="user_id"><strong>Select Maintenance User:</strong></label>
            <select name="user_id" id="user_id" required>
                <option value="">-- Select User --</option>
                <?php foreach ($maintenance_users as $user) { ?>
                    <option value="<?= $user['user_id'] ?>"><?= htmlspecialchars($user['username']) ?></option>
                <?php } ?>
            </select>
            <button type="submit" class="button">Assign User</button>
        </form>

        <!-- Message Display -->
        <?php if (isset($message)) : ?>
            <div class="message <?= $message_type ?>"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
    </div>
</body>
</html>

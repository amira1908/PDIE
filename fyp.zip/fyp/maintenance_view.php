<?php
session_start();
require 'db_connection.php';
include 'maintenance_nav.html';

// Ensure the user is logged in and is a maintenance team member
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'maintenance_team') {
    exit('Access denied.');
}

// Get the logged-in user's ID
$user_id = $_SESSION['user_id'];

// Fetch reports assigned to the maintenance team member
$query = "SELECT * FROM reports WHERE assigned_to = :user_id";
$stmt = $db->prepare($query);
$stmt->execute([':user_id' => $user_id]);
$reports = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maintenance Dashboard</title>
    <style>
        /* Font import for a classic serif font */
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500&family=Roboto&display=swap');

        body {
            font-family: 'Playfair Display', serif;
            background-color: #f5f1e8;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            height: 100vh;
            background-image: url('https://www.transparenttextures.com/patterns/diamond-upholstery.png'); /* Subtle texture */
        }

        .dashboard-container {
            background-color: #fff8e1;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 800px;
            transition: box-shadow 0.3s ease;
            border: 2px solid #c1a24d; /* Gold border */
        }

        h2 {
            color: #3e5c45; /* Dark Green */
            text-align: center;
            margin-bottom: 30px;
            font-size: 28px;
            font-weight: 700;
            text-transform: uppercase;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #c1a24d; /* Gold */
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #e2d69a; /* Light hover effect */
        }

        .view-button {
            text-decoration: none;
            background-color: #3e5c45; /* Dark Green */
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .view-button:hover {
            background-color: #2d4334; /* Darker green on hover */
        }
        
        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: white;
            text-decoration: none;
            padding: 12px;
            background-color: #3e5c45; /* Dark Green */
            border: none;
            border-radius: 5px;
            width: 95%;
            transition: background-color 0.3s ease, transform 0.3s ease;
            font-size: 18px;
        }

        .back-link:hover {
            background-color: #2d4334;
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <h2>Assigned Reports</h2>

        <?php if (count($reports) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Report ID</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reports as $report): ?>
                        <tr>
                            <td><?= htmlspecialchars($report['id']) ?></td>
                            <td><?= htmlspecialchars($report['title']) ?></td>
                            <td><?= htmlspecialchars($report['description']) ?></td>
                            <td><?= htmlspecialchars($report['status']) ?></td>
                            <td>
                                <a href="maintenance_view.php?report_id=<?= htmlspecialchars($report['id']) ?>" class="view-button">View</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No assigned reports.</p>
        <?php endif; ?>

        <a href="maintenance_dashboard.php" class="back-link">Back to Dashboard</a>
    </div>
</body>
</html>

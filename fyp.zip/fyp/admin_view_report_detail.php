<?php
session_start();
ob_start(); // Start output buffering to prevent any output before PDF generation
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'db_connection.php'; // Ensure this file contains your database connection logic

// Include Dompdf library
require 'vendor/autoload.php'; // Make sure this path is correct based on your project structure
use Dompdf\Dompdf;

include 'admin_nav.html'; // Include your navigation (assumed)

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    exit('Access Denied');
}

// Fetch all reports with related maintenance and admin reports
$query = "SELECT r.*, 
                 m.maintenance_team_id, 
                 m.work_result, 
                 m.comment AS maintenance_comment, 
                 m.image AS maintenance_image, 
                 a.admin_id, 
                 a.final_status, 
                 a.final_report_summary, 
                 a.created_at AS admin_created_at 
          FROM reports r
          LEFT JOIN maintenance_reports m ON r.id = m.report_id
          LEFT JOIN admin_reports a ON m.id = a.maintenance_report_id
          WHERE r.id = :report_id"; // Retrieve by specific report ID

// Assuming you get the report_id from the URL or form submission
$report_id = isset($_GET['report_id']) ? $_GET['report_id'] : null;

if ($report_id !== null) {
    $stmt = $db->prepare($query);
    $stmt->bindParam(':report_id', $report_id, PDO::PARAM_INT);
    $stmt->execute();
    $reports = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to generate PDF
function generatePDF($reports, $report_id) {
    // Instantiate Dompdf
    $dompdf = new Dompdf();

    // Create HTML content
    $html = '<h1 style="text-align: center;">Final Report of Facility Issues</h1>';
    
    foreach ($reports as $report) {
        // Applicant report section
        $html .= '<h2>Applicant Report</h2>';
        $html .= '<p><strong>Report ID:</strong> ' . htmlspecialchars($report['id']) . '</p>';
        $html .= '<p><strong>Applicant ID:</strong> ' . htmlspecialchars($report['applicant_id']) . '</p>';
        $html .= '<p><strong>Title:</strong> ' . htmlspecialchars($report['title']) . '</p>';
        $html .= '<p><strong>Description:</strong> ' . htmlspecialchars($report['description']) . '</p>';
        $html .= '<p><strong>Facility Type:</strong> ' . htmlspecialchars($report['facility_type']) . '</p>';
        $html .= '<p><strong>Location:</strong> ' . htmlspecialchars($report['location']) . '</p>';
        $html .= '<p><strong>Submitted At:</strong> ' . htmlspecialchars($report['created_at']) . '</p>';
        $html .= '<p><strong>Status:</strong> ' . htmlspecialchars($report['status']) . '</p>';
        $html .= '<br>';

        // Maintenance report section
        $html .= '<h2>Maintenance Report</h2>';
        $html .= '<p><strong>Maintenance Team ID:</strong> ' . htmlspecialchars($report['maintenance_team_id'] ?? 'N/A') . '</p>';
        $html .= '<p><strong>Work Result:</strong> ' . htmlspecialchars($report['work_result'] ?? 'N/A') . '</p>';
        $html .= '<p><strong>Maintenance Comments:</strong> ' . htmlspecialchars($report['maintenance_comment'] ?? 'No comments') . '</p>';
        $html .= '<br>';

        // Admin report section
        $html .= '<h2>Admin Report</h2>';
        $html .= '<p><strong>Admin Final Status:</strong> ' . htmlspecialchars($report['final_status'] ?? 'N/A') . '</p>';
        $html .= '<p><strong>Admin Summary:</strong> ' . htmlspecialchars($report['final_report_summary'] ?? 'No summary') . '</p>';
        $html .= '<br>';
    }

    // Load HTML content to Dompdf
    $dompdf->loadHtml($html);
    
    // Set paper size and orientation
    $dompdf->setPaper('A4', 'portrait');
    
    // Render the PDF
    $dompdf->render();

    // Send the PDF output
    $dompdf->stream('final_report_' . $report_id . '.pdf', ['Attachment' => true]); // Download the PDF
    exit(); // Important: exit to stop any further output
}

// Check for download PDF request
if (isset($_POST['download_pdf'])) {
    if (!empty($reports)) {
        generatePDF($reports, $report_id);
    } else {
        echo "No reports available to generate PDF."; // Optional feedback
    }
    exit(); // Exit after generating the PDF
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Final Report</title>
    <style>
    /* CSS for Final Report in Monochromatic Theme */
    body {
        font-family: Arial, sans-serif;
        background-color: #f5f5f5; /* Light gray */
        margin: 0;
        padding: 60px;
    }
    .report-container {
        background-color: #ffffff; /* White for contrast */
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        max-width: 800px;
        margin: 0 auto;
    }
    h2 {
        color: #333333; /* Dark gray */
        text-align: center;
        margin-bottom: 30px;
    }
    .report-section {
        margin-bottom: 25px;
        padding: 15px;
        border: 1px solid #cccccc; /* Light gray border */
        border-radius: 8px;
        background-color: #f9f9f9; /* Very light gray */
    }
    .report-section h3 {
        color: #444444; /* Medium dark gray */
        margin-top: 0;
    }
    .download-button, .back-link {
        display: inline-block;
        text-decoration: none;
        background-color: #666666; /* Medium gray */
        color: #ffffff; /* White text */
        padding: 12px 20px;
        border-radius: 5px;
        text-align: center;
        transition: background-color 0.3s;
    }
    .download-button:hover, .back-link:hover {
        background-color: #555555; /* Darker gray on hover */
    }
    .back-link {
        margin-top: 25px;
    }
    .center-image {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }
    .center-image img {
        max-width: 100%;
        max-height: 350px;
        border-radius: 8px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        margin: 15px 0;
    }
</style>

</head>
<body>
    <div class="report-container">
        <h2>Final Report of Facility Issues</h2>

        <div class="form-container">
            <?php if (!empty($reports)): ?>
                <?php foreach ($reports as $report): ?>
                    <div class="report-section">
                        <h3>Applicant Report</h3>
                        <?php if (!empty($report['image'])): ?>
                        <p><strong>Report Image:</strong></p>
                        <div class="center-image">
                            <img src="<?= htmlspecialchars($report['image']) ?>" alt="Report Image">
                        </div>
                        <?php else: ?>
                            <p>No image available for this report.</p>
                        <?php endif; ?>
                        <p><strong>Report ID:</strong> <?= htmlspecialchars($report['id']) ?></p>
                        <p><strong>Applicant ID:</strong> <?= htmlspecialchars($report['applicant_id']) ?></p>
                        <p><strong>Title:</strong> <?= htmlspecialchars($report['title']) ?></p>
                        <p><strong>Description:</strong> <?= htmlspecialchars($report['description']) ?></p>
                        <p><strong>Facility Type:</strong> <?= htmlspecialchars($report['facility_type']) ?></p>
                        <p><strong>Location:</strong> <?= htmlspecialchars($report['location']) ?></p>
                        <p><strong>Submitted At:</strong> <?= htmlspecialchars($report['created_at']) ?></p>
                        <p><strong>Status:</strong> <?= htmlspecialchars($report['status']) ?></p>
                    </div>

                    <div class="report-section">
                        <h3>Maintenance Report</h3>
                        <p><strong>Maintenance Team ID:</strong> <?= htmlspecialchars($report['maintenance_team_id'] ?? 'N/A') ?></p>
                        <p><strong>Work Result:</strong> <?= htmlspecialchars($report['work_result'] ?? 'N/A') ?></p>
                        <p><strong>Maintenance Comments:</strong> <?= htmlspecialchars($report['maintenance_comment'] ?? 'No comments') ?></p>
                    </div>

                    <div class="report-section">
                        <h3>Admin Report</h3>
                        <p><strong>Admin Final Status:</strong> <?= htmlspecialchars($report['final_status'] ?? 'N/A') ?></p>
                        <p><strong>Admin Summary:</strong> <?= htmlspecialchars($report['final_report_summary'] ?? 'No summary') ?></p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No reports found.</p>
            <?php endif; ?>
            <form method="post">
                <button type="submit" name="download_pdf" class="download-button">Download PDF</button>
            </form>
            <a href="admin_dashboard.php" class="back-link">Back to Admin Dashboard</a>
        </div>
    </div>
</body>
</html>

<?php
session_start();
include('db_connection.php');

// Initialize the error message variable
if (!isset($_SESSION['error_message'])) {
    $_SESSION['error_message'] = "";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = htmlspecialchars(trim($_POST['username']));
    $password = $_POST['password'];
    
    // Prepare SQL statement to fetch user data based on username
    $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // User exists, now check the password
        if (password_verify($password, $user['password'])) {
            // Password is correct, set session variables
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username']; // Store the username in session
            $_SESSION['role'] = $user['role'];

            // Clear the error message after successful login
            $_SESSION['error_message'] = "";

            // Logic to handle redirection based on user role
            if ($user['role'] == 'admin' || $user['role'] == 'maintenance_team') {
                header("Location: choose_dashboard.php"); // Redirect admin/maintenance to choose dashboard
            } elseif ($user['role'] == 'applicant') {
                header("Location: applicant_dashboard.php"); // Redirect applicants to their dashboard
            }
            exit(); // Stop further execution after redirect
        } else {
            // Incorrect password
            $_SESSION['error_message'] = "Invalid password!";
        }
    } else {
        // User not found
        $_SESSION['error_message'] = "User does not exist. Please sign up first.";
    }

    // Reload page to reflect the error message properly
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
<style>
        /* Styling for the login page */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f0f0; /* Light gray for the background */
            color: #333; /* Dark gray for text */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        h2 {
            color: #333; /* Dark gray for the header */
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            background-color: white; /* White for form background */
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ced4da; /* Light gray border */
            font-size: 16px;
            transition: border 0.3s;
        }
        input[type="text"]:focus, input[type="password"]:focus {
            border-color: #333; /* Darker border color on focus */
            outline: none;
        }
        input[type="submit"] {
            background-color: #333; /* Dark gray for the submit button */
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
            padding: 12px;
            border-radius: 5px;
            transition: background-color 0.3s;
            width: 100%;
            margin-top: 10px;
        }
        input[type="submit"]:hover {
            background-color: #555; /* Slightly lighter gray on hover */
        }
        a {
            color: #343a40; /* Dark gray for links */
            text-decoration: none;
            display: block;
            text-align: center;
            margin-top: 15px;
        }
        a:hover {
            text-decoration: underline; /* Underline on hover */
        }
        /* Error message styling */
        p.error {
            color: red; /* Red for error messages */
            text-align: center;
            margin-top: 15px;
            font-size: 14px;
        }
</style>
</head>
<body>
    <form method="POST">
        <h2>Login</h2>
        <input type="text" name="username" placeholder="Enter your username" required>
        <input type="password" name="password" placeholder="Enter your password" required>
        
        <!-- Display error message if it exists -->
        <?php if (!empty($_SESSION['error_message'])): ?>
            <p class="error"><?= $_SESSION['error_message'] ?></p>
            <?php $_SESSION['error_message'] = ""; // Clear the error message after displaying ?>
        <?php endif; ?>

        <input type="submit" value="Login">

        <!-- Sign Up Link -->
        <a href="signup.php">Don't have an account yet? Sign Up</a>
    </form>
</body>
</html>

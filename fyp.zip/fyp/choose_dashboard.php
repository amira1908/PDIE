<?php
session_start();

// Redirect users who are not logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header("Location: login.php");
    exit;
}

$role = $_SESSION['role'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Choose Dashboard</title>
    <style>
    /* General body styling */
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f0f0f0; /* Light grey background */
        color: #333;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }

    /* Container for centering the content */
    .container {
        background-color: white;
        padding: 40px;
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        text-align: center;
        width: 100%;
        max-width: 400px;
    }

    /* Styling for the h2 header */
    h2 {
        color: black; /* Header color */
        margin-bottom: 20px;
        font-size: 24px; /* Increase font size */
    }

    /* Styling for the buttons */
    button {
        background-color: darkgrey; /* Darker button color */
        color: white;
        border: none;
        padding: 12px 20px;
        font-size: 16px;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s, transform 0.3s; /* Add transform transition */
        width: 100%;
        margin-top: 10px;
    }

    /* Button hover effect */
    button:hover {
        background-color: #343a40; /* Dark grey on hover */
        transform: scale(1.05); /* Scale effect */
    }

    /* Logout button with a different color */
    .logout-button {
        background-color: #dc3545; /* Red color for logout */
    }

    /* Links to dashboard styled as block-level elements */
    a {
        text-decoration: none;
    }

    /* Paragraph styling */
    p {
        margin-bottom: 20px;
        color: #555;
    }
</style>

</head>
<body>
    <div class="container">
        <h2>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>
        <p>Please choose which dashboard you'd like to access:</p>
        
        <!-- Link to Applicant Dashboard -->
        <a href="applicant_dashboard.php">
            <button>Applicant Dashboard</button>
        </a>
        
        <?php if ($role == 'admin') { ?>
            <!-- Link to Admin Dashboard for admins -->
            <a href="admin_dashboard.php">
                <button>Admin Dashboard</button>
            </a>
        <?php } elseif ($role == 'maintenance_team') { ?>
            <!-- Link to Maintenance Team Dashboard for maintenance team -->
            <a href="maintenance_dashboard.php">
                <button>Maintenance Team Dashboard</button>
            </a>
        <?php } ?>
        
        <!-- Logout button -->
        <a href="logout.php">
            <button class="logout-button">Logout</button>
        </a>
    </div>
</body>
</html>

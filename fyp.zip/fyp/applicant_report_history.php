<?php
session_start();
require 'db_connection.php';
include 'applicant_nav.html';

// Ensure user is logged in and is an applicant
if (!isset($_SESSION['user_id']) ||  ($_SESSION['role'] !== 'applicant' && $_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'maintenance_team')) {
    header("Location: login.php");
    exit;
}

$applicant_id = $_SESSION['user_id'];

// Fetch only resolved reports
$stmt = $db->prepare ("SELECT * FROM reports WHERE assigned_to = :user_id AND status IN ('Resolved', 'Final Report'ORDER BY created_at DESC");
$stmt->execute([$applicant_id]);
$reports = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report History</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f0f0; /* Light grey background */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .history-container {
            background-color: white; /* White background for the container */
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2); /* Darker shadow */
            width: 100%;
            max-width: 800px;
        }

        h2 {
            color: #333; /* Dark grey for the heading */
            text-align: center;
            margin-bottom: 20px;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            background-color: #e9ecef; /* Light grey for list items */
            margin-bottom: 10px;
            padding: 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        li:hover {
            background-color: #dee2e6; /* Slightly darker grey on hover */
        }

        a {
            color: #333; /* Dark grey for links */
            text-decoration: none;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline; /* Underline on hover */
        }

        .back-link {
            display: block;
            text-align: left;
            margin-top: 20px;
            color: grey; /* Grey color for back link */
            text-decoration: none;
        }

        .back-link:hover {
            text-decoration: underline; /* Underline on hover */
        }

        p {
            text-align: center;
            color: #555; /* Medium grey for paragraph text */
        }
    </style>
</head>
<body>
    <div class="history-container">
    <a href="applicant_dashboard.php" class="back-link">Back to Dashboard</a>
        <h2>Your Resolved Reports</h2>

        <?php if (count($reports) > 0): ?>
            <ul>
                <?php foreach ($reports as $report): ?>
                    <li>
                        <a href="applicant_history_detail.php?report_id=<?= $report['id'] ?>">
                            <?= htmlspecialchars($report['title']) ?> (Resolved on <?= date('F j, Y, g:i a', strtotime($report['updated_at'])) ?>)
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>No resolved reports found.</p>
        <?php endif; ?>

       
    </div>
</body>
</html>

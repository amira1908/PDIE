<?php
session_start();
require 'db_connection.php'; // Ensure this file contains your PDO connection
include 'admin_nav.html';

// Check if the user is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Get the status from the URL
$status = isset($_GET['status']) ? $_GET['status'] : 'unassigned';

// Prepare and execute the query to fetch reports by status
$query = "SELECT * FROM reports WHERE status = :status";
$stmt = $db->prepare($query);
$stmt->bindParam(':status', $status);
$stmt->execute();
$reports = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle marking a maintenance report as resolved
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['mark_resolved'])) {
    $report_id = $_POST['report_id'];
    $update_query = "UPDATE reports SET status = 'resolved' WHERE id = :report_id AND is_maintenance_report = '1'";
    $update_stmt = $db->prepare($update_query);
    $update_stmt->bindParam(':report_id', $report_id);
    $update_stmt->execute();
    header("Location: " . $_SERVER['REQUEST_URI']); // Redirect to the same page
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars(ucfirst($status)) ?> Reports</title>
   <style>
    body {
        font-family: 'Arial', sans-serif; /* Clean sans-serif typography */
        background-color: #f8f8f8; /* Light grey background */
        margin: 0;
        padding: 60px; /* Reduced padding for a more compact layout */
        color: #333; /* Dark grey text */
    }

    .container {
        padding: 40px;
        max-width: 800px;
        margin: auto;
        background-color: #ffffff; /* White background */
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    h2 {
        text-align: center;
        color: #333; /* Dark grey for headers */
        margin-bottom: 20px; /* Added margin for spacing */
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    th, td {
        border: 1px solid #ccc; /* Light grey border */
        padding: 10px;
        text-align: center;
    }

    th {
        background-color: #f0f0f0; /* Slightly darker grey for headers */
        color: #333; /* Dark grey for text */
    }

    tr:nth-child(even) {
        background-color: #f9f9f9; /* Light grey for even rows */
        color: #333; /* Dark grey for text */
    }

    .button {
        background-color: #333; /* Dark grey */
        color: #ffffff; /* White text */
        border: none;
        padding: 10px 20px;
        margin: 10px 0;
        cursor: pointer;
        border-radius: 5px;
        text-decoration: none;
        display: inline-block; /* Ensures the button behaves like a block element */
    }

    .button:hover {
        background-color: #555; /* Lighter grey on hover */
    }
</style>

</head>
<body>
    <div class="container">
        <h2><?= htmlspecialchars(ucfirst($status)) ?> Reports</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Report Title</th>
                <th>Status</th>
                <th>Created At</th>
                <th>Action</th>
            </tr>
            <?php foreach ($reports as $report) { ?>
            <tr>
                <td><?= htmlspecialchars($report['id']) ?></td>
                <td><?= htmlspecialchars($report['title']) ?></td>
                <td><?= htmlspecialchars($report['status']) ?></td>
                <td><?= htmlspecialchars($report['created_at']) ?></td>
                <td>
                    <?php if ($status === 'pending') { ?>
                        <a href="admin_assign_team.php?report_id=<?= $report['id'] ?>" class="button">Assign Maintenance Team</a>
                    <?php } elseif ($status === 'assigned') { ?>
                    <?php } elseif ($status === 'accepted') { ?>
                    <?php } elseif ($status === 'resolved') { ?>
                        <a href="admin_create_final_report.php?report_id=<?= $report['id'] ?>" class="button">Create Final Report</a>
                    <?php } elseif ($status === 'final report') { ?>
                        <a href="admin_view_report_detail.php?report_id=<?= $report['id'] ?>" class="button">View Details</a>
                    <?php } elseif ($status === 'problem occur') { ?>
                        <a href="admin_create_final_report.php?report_id=<?= $report['id'] ?>" class="button">Create Final Report</a>
                    <?php } elseif ($status === 'in progress' && $report['is_maintenance_report'] == '1') { ?>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="report_id" value="<?= $report['id'] ?>">
                            <button type="submit" name="mark_resolved" class="button">Mark as Resolved</button>
                        </form>
                    <?php } ?>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>

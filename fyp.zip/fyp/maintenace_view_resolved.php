<?php
session_start();
require 'db_connection.php';
include 'maintenance_nav.html';

// Ensure the user is logged in and is a maintenance team member
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'maintenance_team') {
    exit('Access denied.');
}

$report_id = $_GET['report_id'];

// Fetch the specific report based on report_id
$query = "SELECT * FROM reports WHERE id = :report_id";
$stmt = $db->prepare($query);
$stmt->execute([':report_id' => $report_id]);
$report = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if the report exists
if (!$report) {
    echo "Report not found.";
    exit;
}

// Extract report details
$image = $report['image'] ?? null; 
$title = $report['title'] ?? ''; 
$description = $report['description'] ?? ''; 
$facility_type = $report['facility_type'] ?? ''; 
$location = $report['location'] ?? ''; 
$created_at = $report['created_at'] ?? ''; 
$updated_at = $report['updated_at'] ?? ''; 
$status = $report['status'] ?? ''; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Detail</title>
    <style>
        /* Font import for a classic serif font */
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500&family=Roboto&display=swap');

        body {
            font-family: 'Playfair Display', serif;
            background-color: lightgrey; /* Light grey background */
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            color: #333; /* Dark text color for contrast */
        }

        .progress-container {
            background-color: #ffffff; /* White for container */
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 700px;
            border: 2px solid #444; /* Slightly darker grey border */
        }

        h2 {
            color: #333; /* Dark heading */
            text-align: center;
            margin-bottom: 30px;
            font-size: 28px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .form-container {
            display: flex;
            flex-direction: column;
            gap: 15px;
            background-color: #f9f9f9; /* Very light grey for form background */
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #ddd; /* Light grey border */
        }

        .form-container p {
            font-size: 17px;
            color: #555; /* Dark grey for text */
            margin: 5px 0;
        }

        .form-container p strong {
            font-weight: 600;
            color: #333; /* Dark strong text */
        }

        img {
            display: block;
            margin: 20px auto;
            max-width: 220px;
            border-radius: 8px;
            border: 2px solid #ddd; /* Light grey border */
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #ffffff; /* White text */
            text-decoration: none;
            padding: 12px;
            background-color: #444; /* Dark grey button */
            border-radius: 5px;
            width: 95%;
            transition: background-color 0.3s ease;
            font-size: 16px; /* Increase font size */
            font-weight: bold; /* Make the text bold */
        }

        .back-link:hover {
            background-color: #555; /* Lighter grey on hover */
            text-decoration: none;
        }

        /* Additional styling for buttons */
        .button {
            background-color: #666; /* Darker button */
            color: #ffffff; /* White text */
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .button:hover {
            background-color: #777; /* Even lighter grey on hover */
        }

        /* Table styles */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd; /* Light grey */
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2; /* Light grey for header */
            color: #333; /* Dark text */
        }

        tr:nth-child(even) {
            background-color: #f9f9f9; /* Very light grey */
        }

        tr:hover {
            background-color: #e0e0e0; /* Slightly darker grey on hover */
        }

        .view-detail {
            color: #333; /* Dark text */
            text-decoration: none;
            font-weight: bold;
        }

        .view-detail:hover {
            text-decoration: underline;
            color: #555; /* Darker grey on hover */
        }
    </style>

</head>
<body>
    <div class="progress-container">
        <h2>Report Detail</h2>

        <div class="form-container">
            <?php if ($image): ?>
                <p><strong>Uploaded Image:</strong></p>
                <img src="<?= htmlspecialchars($image) ?>" alt="Report Image">
            <?php endif; ?>
            <p><strong>Title:</strong> <?= htmlspecialchars($title) ?></p>
            <p><strong>Description:</strong> <?= htmlspecialchars($description) ?></p>
            <p><strong>Facility Type:</strong> <?= htmlspecialchars($facility_type) ?></p>
            <p><strong>Location:</strong> <?= htmlspecialchars($location) ?></p>
            <p><strong>Created At:</strong> <?= htmlspecialchars($created_at) ?></p>
            <p><strong>Date Resolved:</strong> <?= htmlspecialchars($updated_at) ?></p>
            <p><strong>Status:</strong> <?= htmlspecialchars($status) ?></p>
        </div>

        <a href="maintenance_resolve_report.php" class="back-link">Back to Resolved Reports</a>
    </div>
</body>
</html>

<?php
session_start();
require 'db_connection.php';
include 'applicant_nav.html';

// Check if the user is logged in and is an applicant
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'applicant' && $_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'maintenance_team')) {
    header("Location: login.php"); // Redirect to login if not logged in or not an applicant
    exit;
}

// Fetch report data for the logged-in applicant
$applicant_id = $_SESSION['user_id'];
$sql = "SELECT id, title, status, created_at FROM reports WHERE applicant_id = ?";
$stmt = $db->prepare($sql);
$stmt->execute([$applicant_id]);
$reports = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Applicant Dashboard</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: lightgrey;
            margin: 0;
            padding: 0;
        }

        .dashboard-container {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            margin: 120px auto; /* Position below nav */
            color: #333;
        }

        h1 {
            font-size: 24px;
            color: #333;
            text-align: center;
        }

        .report-summary {
            margin-top: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #333;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f4f6f9;
        }

        /* Status Colors */
        .status-pending {
            color: red;
            font-weight: bold;
        }

        .status-in-progress {
            color: orange;
            font-weight: bold;
        }

        .status-resolved {
            color: green;
            font-weight: bold;
        }

        /* Button Styling */
        .view-details {
            background-color: #333;
            color: white;
            padding: 8px 12px;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .view-details:hover {
            background-color: #555;
        }
    </style>
</head>
<body>

    <!-- Dashboard Container -->
    <div class="dashboard-container">
        <h1>Welcome to Your Dashboard, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
        <p class="intro-text">Here is an overview of your report status:</p>
        
        <!-- Report Summary Table -->
        <div class="report-summary">
            <?php if (!empty($reports)) { ?>
                <table>
                    <thead>
                        <tr>
                            <th>Report Title</th>
                            <th>Status</th>
                            <th>Date Submitted</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reports as $report) { ?>
                            <tr>
                                <td><?php echo htmlspecialchars($report['title']); ?></td>
                                <td class="<?php echo 'status-' . strtolower(str_replace(' ', '-', $report['status'])); ?>">
                                    <?php echo htmlspecialchars($report['status']); ?>
                                </td>
                                <td><?php echo htmlspecialchars($report['created_at']); ?></td>
                                <td><a href="applicant_report_progress.php?report_id=<?php echo $report['id']; ?>" class="view-details">View Details</a></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            <?php } else { ?>
                <p>No reports found. <a href="applicant_submit_report.php" class="view-details">Submit a new report</a>.</p>
            <?php } ?>
        </div>
    </div>

</body>
</html>

<?php
session_start();
require 'db_connection.php';
include 'applicant_nav.html';

// Ensure user is logged in and is an applicant
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'applicant' && $_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'maintenance_team')) {
    header("Location: login.php");
    exit;
}

// Initialize error and success messages
$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $facility_type = $_POST['facility_type'];
    $location = $_POST['location'];
    $applicant_id = $_SESSION['user_id'];
    $image = null;

    // Handle file upload if a file is selected
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $image_name = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];
        $image_ext = pathinfo($image_name, PATHINFO_EXTENSION);
        $allowed_exts = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array(strtolower($image_ext), $allowed_exts)) {
            $image_path = 'uploads/' . uniqid() . '.' . $image_ext;
            move_uploaded_file($image_tmp, $image_path);
            $image = $image_path;
        } else {
            $error_message = "Invalid file type. Only JPG, JPEG, PNG, and GIF are allowed.";
        }
    }

    // If no errors with the image, insert the report into the database
    if (empty($error_message)) {
        try {
            $stmt = $db->prepare("INSERT INTO reports (applicant_id, title, description, facility_type, location, image, status, created_at) VALUES (?, ?, ?, ?, ?, ?, 'Pending', NOW())");
            $stmt->execute([$applicant_id, $title, $description, $facility_type, $location, $image]);

            // Redirect to report progress page after successful submission
            $last_report_id = $db->lastInsertId();
            header("Location: applicant_report_progress.php?report_id=$last_report_id");
            exit;
        } catch (PDOException $e) {
            $error_message = "Error submitting the report. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Facility Report</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f0f0; /* Light grey background */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .form-container {
            background-color: #ffffff; /* White container */
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
        }

        h1 {
            color: #333333; /* Dark grey */
            margin-bottom: 20px;
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-top: 10px;
            font-weight: bold;
            color: #555555; /* Medium grey */
        }

        input[type="text"],
        textarea,
        select {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #cccccc; /* Light grey */
            margin-top: 5px;
            width: 100%;
            background-color: #f9f9f9; /* Very light grey */
        }

        input[type="file"] {
            margin-top: 5px;
        }

        input[type="submit"] {
            background-color: #333333; /* Dark grey */
            color: white;
            padding: 10px;
            margin-top: 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #555555; /* Medium grey on hover */
        }

        p {
            color: red;
            text-align: center;
        }

        a {
            text-align: center;
            display: block;
            margin-top: 20px;
            color: #007bff; /* Blue */
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="form-container">
        <h1>Submit a New Facility Report</h1>

        <?php if (!empty($error_message)): ?>
            <p><?= htmlspecialchars($error_message) ?></p>
        <?php endif; ?>

        <form action="applicant_submit_report.php" method="POST" enctype="multipart/form-data">
            <label for="title">Report Title:</label>
            <input type="text" name="title" id="title" required>

            <label for="description">Description:</label>
            <textarea name="description" id="description" rows="4" required></textarea>

            <label for="facility_type">Facility Type:</label>
            <select name="facility_type" id="facility_type" required>
                <option value="Wi-Fi">Wi-Fi</option>
                <option value="Electricity">Electricity</option>
                <option value="Air Conditioning">Air Conditioning</option>
                <option value="Furniture">Furniture</option>
                <option value="Other">Other</option>
            </select>

            <label for="location">Location:</label>
            <input type="text" name="location" id="location" required><br>

            <label for="image">Upload Image (Optional):</label>
            <input type="file" name="image" id="image">

            <input type="submit" value="Submit Report">
        </form>

        <a href="applicant_dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>

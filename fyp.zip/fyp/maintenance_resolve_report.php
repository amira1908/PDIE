<?php
session_start();
require 'db_connection.php';
include 'maintenance_nav.html';

// Ensure the user is logged in and is a maintenance team member
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'maintenance_team') {
    exit('Access denied.');
}

// Get the logged-in user's ID
$user_id = $_SESSION['user_id'];

// Fetch resolved reports assigned to the maintenance team member
$query = "SELECT * FROM reports WHERE assigned_to = :user_id AND status IN ('Resolved', 'Final Report')";
$stmt = $db->prepare($query);
$stmt->execute([':user_id' => $user_id]);
$resolved_reports = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resolved Report History</title>
    <style>
    /* Style definitions remain the same */
    body {
        font-family: 'Playfair Display', serif;
        background-color: #f5f1f1; /* Light grey background */
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        height: 100vh; /* Full viewport height */
        }

    .dashboard-container {
        background-color: #ffffff; /* White background for the dashboard */
        padding: 40px;
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); /* Light shadow */
        width: 100%;
        max-width: 800px;
        border: 2px solid #888; /* Grey border */
    }

    h2 {
        color: #000000; /* Black text for the heading */
        text-align: center;
        margin-bottom: 30px;
        font-size: 28px;
        font-weight: 700;
        text-transform: uppercase;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    th, td {
        border: 1px solid #ddd; /* Light grey border for table cells */
        padding: 12px;
        text-align: left;
    }

    th {
        background-color: #555; /* Dark grey for table header */
        color: white; /* White text in the header */
    }

    tr:nth-child(even) {
        background-color: #f2f2f2; /* Light grey for even rows */
    }

    tr:hover {
        background-color: #e0e0e0; /* Grey hover effect for rows */
    }

    .view-detail {
        color: #000000; /* Black link color */
        text-decoration: none;
        font-weight: bold;
    }

    .view-detail:hover {
        text-decoration: underline; /* Underline on hover */
    }

    .back-link {
        display: block;
        text-align: center;
        margin-top: 20px;
        color: white; /* White text for the back link */
        text-decoration: none;
        padding: 12px;
        background-color: #333; /* Dark grey for the back link */
        border-radius: 5px;
        width: 95%;
        transition: background-color 0.3s ease; /* Smooth transition */
    }

    .back-link:hover {
        background-color: #555; /* Medium grey on hover */
        text-decoration: none;
    }
</style>

</style>


</head>
<body>
    <div class="dashboard-container">
        <h2>Resolved Report History</h2>

        <?php if (count($resolved_reports) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Report ID</th>
                        <th>Title</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($resolved_reports as $report): ?>
                        <tr>
                            <td><?= htmlspecialchars($report['id']) ?></td>
                            <td><?= htmlspecialchars($report['title']) ?></td>
                            <td><?= htmlspecialchars($report['created_at']) ?></td>
                            <td><?= htmlspecialchars($report['updated_at']) ?></td> <!-- Assuming there's a date_resolved field -->
                            <td><a href="maintenace_view_resolved.php?report_id=<?= htmlspecialchars($report['id']) ?>" class="view-detail">View Details</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No resolved reports found.</p>
        <?php endif; ?>

        <a href="maintenance_dashboard.php" class="back-link">Back to Dashboard</a>
    </div>
</body>
</html>

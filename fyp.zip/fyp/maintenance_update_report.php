<?php
session_start();
require 'db_connection.php';
include 'maintenance_nav.html';

// Ensure the user is logged in and is a maintenance team member
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'maintenance_team') {
    exit;
}

$report_id = $_GET['report_id'];

// Fetch the specific report based on report_id
$query = "SELECT * FROM reports WHERE id = :report_id";
$stmt = $db->prepare($query);
$stmt->execute([':report_id' => $report_id]);
$report = $stmt->fetch(PDO::FETCH_ASSOC);


// Extract report details
$image = $report['image'] ?? null; 
$title = $report['title'] ?? ''; 
$description = $report['description'] ?? ''; 
$facility_type = $report['facility_type'] ?? ''; 
$location = $report['location'] ?? ''; 
$created_at = $report['created_at'] ?? ''; 
$status = $report['status'] ?? ''; 

// Handle form submission for status update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_status = $_POST['status'];
    
    // Update the report status in the database
    $update_query = "UPDATE reports SET status = :status WHERE id = :report_id";
    $update_stmt = $db->prepare($update_query);
    $update_stmt->execute([':status' => $new_status, ':report_id' => $report_id]);
    
    // Optionally redirect or display a success message
    header("Location: maintenance_dashboard.php?report_id=$report_id");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Progress</title>
    <style>
    /* Font import for a classic serif font */
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500&family=Roboto&display=swap');

    body {
        font-family: 'Playfair Display', serif; /* Serif font for a classic look */
        background-color: #ffffff; /* White background for contrast */
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        height: 100vh;
        color: #333; /* Dark grey for text */
    }

    .progress-container {
        background-color: #f9f9f9; /* Light grey for the container */
        padding: 40px;
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2); /* Darker shadow for depth */
        width: 100%;
        max-width: 700px;
        transition: box-shadow 0.3s ease;
        border: 2px solid #cccccc; /* Light grey border */
    }

    h2 {
        color: #333; /* Dark grey for the header */
        text-align: center;
        margin-bottom: 30px;
        font-size: 28px;
        font-weight: 700;
        text-transform: uppercase;
    }

    .form-container {
        display: flex;
        flex-direction: column;
        gap: 15px;
        background-color: #ffffff; /* White background for the form */
        padding: 20px;
        border-radius: 8px;
        border: 1px solid #dddddd; /* Light grey border */
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .form-container p {
        font-size: 17px;
        color: #333; /* Dark grey for paragraph text */
        margin: 5px 0;
    }

    .form-container p strong {
        font-weight: 600;
        color: #555; /* Medium grey for strong text */
    }

    img {
        display: block;
        margin: 20px auto;
        max-width: 220px;
        border-radius: 8px;
        border: 2px solid #cccccc; /* Light grey border */
    }

    /* Flex container for buttons */
    .button-container {
        display: flex;
        justify-content: space-between;
        gap: 20px;
        margin-top: 15px;
    }

    .button-container a {
        display: inline-block;
        text-decoration: none;
        background-color: #777; /* Medium grey button */
        color: white;
        padding: 10px 20px;
        border-radius: 5px;
        font-size: 16px;
        font-family: 'Roboto', sans-serif;
        text-align: center;
        flex-grow: 1;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        transition: background-color 0.3s ease;
    }

    .button-container a:hover {
        background-color: #555; /* Darker grey on hover */
    }

    .back-link {
        display: block;
        text-align: center;
        margin-top: 20px;
        color: white;
        text-decoration: none;
        padding: 12px;
        background-color: #333; /* Dark grey */
        border: none;
        border-radius: 5px;
        width: 95%;
        transition: background-color 0.3s ease, transform 0.3s ease;
        font-size: 18px;
    }

    .back-link:hover {
        background-color: #222; /* Darker grey on hover */
        transform: scale(1.05);
        text-decoration: none;
    }

    /* Style for status update form */
    .status-update {
        display: flex;
        flex-direction: column;
        margin-top: 20px;
    }

    .status-update label {
        margin-bottom: 5px;
        font-weight: bold;
        color: #333; /* Dark grey for label text */
    }

    .status-update select {
        padding: 10px;
        border-radius: 5px;
        border: 1px solid #ccc; /* Light grey border */
        font-size: 16px;
    }

    .update-button {
        margin-top: 15px;
        padding: 10px;
        border: none;
        background-color: #333; /* Dark grey button */
        color: white;
        font-size: 16px;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .update-button:hover {
        background-color: #222; /* Darker grey on hover */
    }
</style>

</head>
<body>
    <div class="progress-container">
        <h2>Report Detail</h2>

        <div class="form-container">
            <?php if ($image): ?>
                <p><strong>Uploaded Image:</strong></p>
                <img src="<?= htmlspecialchars($image) ?>" alt="Report Image">
            <?php endif; ?>

            <p><strong>Report Title:</strong> <?= htmlspecialchars($title) ?></p>
            <p><strong>Description:</strong> <?= htmlspecialchars($description) ?></p>
            <p><strong>Facility Type:</strong> <?= htmlspecialchars($facility_type) ?></p>
            <p><strong>Location:</strong> <?= htmlspecialchars($location) ?></p>
            <p><strong>Submitted At:</strong> <?= htmlspecialchars($created_at) ?></p>
            <p><strong>Status:</strong> <?= htmlspecialchars($status) ?></p>
        </div>

        <!-- Status update form -->
        <div class="status-update">
            <form method="POST">
                <label for="status">Update Status:</label>
                <select name="status" id="status" required>
                    <option value="Accepted" <?= $status === 'Accepted' ? 'selected' : '' ?>>Accepted</option>
                    <option value="In Progress" <?= $status === 'In Progress' ? 'selected' : '' ?>>In Progress</option>
                    <option value="Issue" <?= $status === 'Issue' ? 'selected' : '' ?>>Issue</option>
                </select>
                <button type="submit" class="update-button">Update Status</button>
            </form>
        </div>

        <a href="maintenance_dashboard.php" class="back-link">Back to Dashboard</a>
    </div>
</body>
</html>

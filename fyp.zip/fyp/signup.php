<?php
include('db_connection.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $role = $_POST['role'];

    // Initialize staff_id and special_password to null
    $staff_id = null;
    $special_password = null;
    $specialty = null;

    // Check role and assign staff_id and special_password if applicable
    if ($role === 'admin' || $role === 'maintenance_team') {
        $staff_id = $_POST['staff_id'];
        $special_password = $_POST['special_password'];

        if ($role === 'maintenance_team') {
            $specialty = $_POST['specialty'];
        }

        // Validate staff_id and special password for admin and maintenance team roles
        if (empty($staff_id)) {
            echo "<script>alert('Staff ID is required for Admin and Maintenance Team!'); window.location.href='signup.php';</script>";
            exit();
        }

        // Validate special password
        if (($role === 'admin' && $special_password !== 'admin1234') || ($role === 'maintenance_team' && $special_password !== 'staff1234')) {
            echo "<script>alert('Invalid special password!'); window.location.href='signup.php';</script>";
            exit; // Stop execution if the password is incorrect
        }
    }

    // Check if passwords match
    if ($password !== $confirm_password) {
        echo "<script>alert('Passwords do not match! Please try again.'); window.location.href='signup.php';</script>";
        exit(); // Stop execution if passwords do not match
    }

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Prepare SQL statement to insert user data
    $stmt = $db->prepare("INSERT INTO users (username, email, password, role, staff_id, specialty) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$username, $email, $hashed_password, $role, $staff_id, $specialty]);

    // Redirect to login page after successful registration
    header("Location: login.php");
    exit(); // Ensure no further code is executed after the redirect
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa; /* Light gray for the background */
            color: #495057; /* Dark gray for text */
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        h1 {
            color: #343a40; /* Dark gray for the header */
            text-align: center;
        }

        form {
            background-color: #ffffff; /* White for form background */
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2); /* Slightly darker shadow */
            width: 100%;
            max-width: 400px;
        }

        input, select {
            width: 95%;
            padding: 12px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ced4da; /* Light gray border */
            font-size: 16px;
            background-color: #f8f9fa; /* Light gray for inputs */
        }

        input[type="submit"] {
            background-color: #333; /* Dark gray for the submit button */
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
            padding: 12px;
            border-radius: 5px;
            transition: background-color 0.3s;
            width: 100%;
            margin-top: 10px;
        }
        input[type="submit"]:hover {
            background-color: #555; /* Slightly lighter gray on hover */
        }

        a {
            color: #343a40; /* Dark gray for links */
            text-decoration: none;
            display: block;
            text-align: center;
            margin-top: 15px;
        }

        #extra-fields {
            display: none;
        }
    </style>
</head>
<body>
    <form method="POST">
        <h1>Sign Up</h1>
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" placeholder="Enter your username" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" placeholder="Enter your email" required>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" placeholder="Enter your password" required>

        <label for="confirm_password">Confirm Password:</label>
        <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm your password" required>

        <label for="role">Role:</label>
        <select name="role" id="role" required>
            <option value="applicant">Applicant</option>
            <option value="admin">Admin</option>
            <option value="maintenance_team">Maintenance Team</option>
        </select>

        <div id="extra-fields">
            <label for="staff_id">Staff ID:</label>
            <input type="text" id="staff_id" name="staff_id" placeholder="Enter your Staff ID">

            <label for="special_password">Special Password:</label>
            <input type="password" id="special_password" name="special_password" placeholder="Enter the special password">

            <div id="extra">
                <label for="specialty">Specialty:</label>
                <select id="specialty" name="specialty">
                    <option value="electrician">Electrician</option>
                    <option value="plumber">Plumber</option>
                    <option value="carpenter">Carpenter</option>
                    <option value="it technician">IT Technician</option>
                    <option value="locksmith">Locksmith</option>
                    <option value="general_maintenance">General Maintenance</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
        </div>

        <input type="submit" value="Sign Up">

        <a href="login.php">Have an account already? Log In</a>
    </form>

    <script>
        document.querySelector('select[name="role"]').addEventListener('change', function() {
            document.getElementById('extra-fields').style.display = this.value === 'admin' || this.value === 'maintenance_team' ? 'block' : 'none';
            document.getElementById('extra').style.display = this.value === 'maintenance_team'? 'block' : 'none';
        });
    </script>
</body>
</html>

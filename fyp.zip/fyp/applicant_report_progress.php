<?php
session_start();
require 'db_connection.php';
include 'applicant_nav.html';

// Ensure the user is logged in and is an applicant
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'applicant' && $_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'maintenance_team')) {
    exit;
}

// Ensure the report ID is provided
if (!isset($_GET['report_id'])) {
    echo "No report ID provided.";
    exit;
}

$report_id = $_GET['report_id'];

// Fetch the report details from the database
try {
    $stmt = $db->prepare("SELECT * FROM reports WHERE id = ? AND applicant_id = ?");
    $stmt->execute([$report_id, $_SESSION['user_id']]);
    $report = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$report) {
        echo "No report found or you don't have permission to view this report.";
        exit;
    }
    $report_status = $report['status']; 
    if ($report_status === "Final Report") {
        $report_status = "Resolved";
    }

} catch (PDOException $e) {
    echo "Error fetching the report. Please try again.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Progress</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f4; /* Light grey background */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        h2 {
            color: #333; /* Dark grey for the heading */
            text-align: center;
            margin-bottom: 20px;
            font-size: 24px;
        }

        .form-container {
            display: flex;
            flex-direction: column;
            gap: 10px;
            background-color: #fff; /* White background for container */
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #ccc; /* Light grey border */
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            max-width: 600px; /* Fixed width */
            margin: 0 auto; /* Center the container */
        }

        .form-container p {
            font-size: 16px;
            color: #333; /* Dark grey for text */
            margin: 5px 0;
        }

        .form-container p strong {
            font-weight: 600;
        }

        img {
            display: block;
            margin: 20px auto;
            max-width: 200px;
            border-radius: 8px;
            border: 2px solid #ccc; /* Light grey border for image */
        }

        .progress-bar-container {
            width: 100%;
            margin: 20px 0;
        }

        .progress-bar {
            width: 100%;
            height: 10px;
            background-color: #ddd; /* Light grey for background */
            border-radius: 5px;
            overflow: hidden;
        }

        .progress {
            height: 100%;
            background-color: green; /* Dark grey for normal progress */
            transition: width 0.5s ease, background-color 0.5s ease;
        }

        .progress.issue {
            background-color: #ff0000; /* Red when there is an issue */
        }

        .progress-labels {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
        }

        .label {
            font-size: 12px;
            color: #777; /* Grey for labels */
        }

        .label.active {
            font-weight: bold;
            color: #333; /* Dark grey for active label */
        }

        .label.issue {
            font-weight: bold;
            color: #ff0000; /* Red text when issue occurs */
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: white;
            text-decoration: none;
            padding: 12px; /* Increased padding */
            background-color: #333; /* Dark grey for button */
            border: none;
            border-radius: 5px;
            width: 95%; /* Full width */
            transition: background-color 0.3s ease, transform 0.3s ease;
            font-size: 18px; /* Larger font size */
        }

        .back-link:hover {
            background-color: #555; /* Slightly lighter grey on hover */
            transform: scale(1.05);
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="progress-container">
        <h2>Report Progress</h2>

        <div class="form-container">
            <?php if ($report['image']): ?>
                <p><strong>Uploaded Image:</strong></p>
                <img src="<?= htmlspecialchars($report['image']) ?>" alt="Report Image">
            <?php endif; ?>
            <p><strong>Report Title:</strong> <?= htmlspecialchars($report['title']) ?></p>
            <p><strong>Description:</strong> <?= htmlspecialchars($report['description']) ?></p>
            <p><strong>Facility Type:</strong> <?= htmlspecialchars($report['facility_type']) ?></p>
            <p><strong>Location:</strong> <?= htmlspecialchars($report['location']) ?></p>
            <p><strong>Submitted At:</strong> <?= htmlspecialchars($report['created_at']) ?></p>
        </div><br>

        <div class="progress-bar-container">
            <div class="progress-bar">
                <div class="progress" id="progress-bar" style="width: 0%;"></div>
            </div>
            <div class="progress-labels">
                <span class="label" id="label-pending">Pending</span>
                <span class="label" id="label-assigned">Assigned</span>
                <span class="label" id="label-accepted">Accepted</span>
                <span class="label" id="label-in-progress">In Progress</span>
                <span class="label" id="label-issue">Issue</span>
                <span class="label" id="label-resolved">Resolved</span>
                
            </div>
        </div>

        <a href="applicant_dashboard.php" class="back-link">Back to Dashboard</a>
    </div>

    <!-- JavaScript for progress bar animation -->
    <script>
        function updateProgressBar(status) {
            var progressBar = document.getElementById("progress-bar");
            var labels = document.querySelectorAll(".label");

            // Reset progress bar and labels
            progressBar.classList.remove("issue");
            labels.forEach(label => label.classList.remove("active", "issue"));

            // Update progress bar based on status
            switch (status) {
                case 'Pending':
                    progressBar.style.width = "0%";
                    document.getElementById("label-pending").classList.add("active");
                    break;
                case 'Assigned':
                    progressBar.style.width = "20%";
                    document.getElementById("label-assigned").classList.add("active");
                    break;
                case 'Accepted':
                    progressBar.style.width = "40%";
                    document.getElementById("label-accepted").classList.add("active");
                    break;
                case 'In Progress':
                    progressBar.style.width = "60%";
                    document.getElementById("label-in-progress").classList.add("active");
                    break;
                case 'Issue':
                    progressBar.style.width = "80%";
                    progressBar.classList.add("issue");
                    document.getElementById("label-issue").classList.add("active", "issue");
                    break;
                case 'Resolved':
                    progressBar.style.width = "100%";
                    document.getElementById("label-resolved").classList.add("active");
                    break;
            }
        }

        // Use PHP to pass the current status to JavaScript
        const reportStatus = "<?= htmlspecialchars($report_status) ?>";
        updateProgressBar(reportStatus);  // Initialize progress bar with current status
    </script>
</body>
</html>
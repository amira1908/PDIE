<?php
session_start();
require 'db_connection.php';

// Check if user is logged in and is part of the maintenance team
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'maintenance_team') {
    header("Location: login.php");
    exit;
}

// Fetch report ID from the URL
$report_id = $_GET['report_id'];

// Fetch the report details to check its status
$reportQuery = "SELECT status FROM reports WHERE id = ?";
$reportStmt = $db->prepare($reportQuery);
$reportStmt->execute([$report_id]);
$report = $reportStmt->fetch(PDO::FETCH_ASSOC);

// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $maintenance_team_id = $_SESSION['user_id']; // Get the ID of the logged-in maintenance team member
    $work_result = $_POST['work_result'];
    $comment = $_POST['comment'];
    
    // Handle image upload
    $image = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "uploads/"; // Directory where images will be stored
        $target_file = $target_dir . basename($_FILES["image"]["name"]);
        
        // Move uploaded file to the target directory
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $image = $target_file; // Save the path of the uploaded image
        }
    }

    // Insert the maintenance report into the database
    $query = "INSERT INTO maintenance_reports (maintenance_team_id, report_id, work_result, comment, image, created_at) VALUES (?, ?, ?, ?, ?, NOW())";
    $stmt = $db->prepare($query);
    $stmt->execute([$maintenance_team_id, $report_id, $work_result, $comment, $image]);

    // Update the is_maintenance_report column in the reports table
    $updateQuery = "UPDATE reports SET is_maintenance_report = 1 WHERE id = ?";
    $updateStmt = $db->prepare($updateQuery);
    $updateStmt->execute([$report_id]);

    // Redirect or display a success message
    header("Location: maintenance_dashboard.php?success=Report submitted successfully");
    exit;
}

// If the status is "In Progress", allow marking it as resolved
$canMarkResolved = ($report && $report['status'] === 'In Progress');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Maintenance Report</title>
</head>
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: lightgrey; /* Light grey background */
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            color: #333; /* Dark text color for contrast */
        }

        h2 {
            color: #333; /* Dark heading */
            margin-bottom: 20px;
        }

        form {
            background-color: #ffffff; /* White background for the form */
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        textarea {
            width: 100%;
            height: 80px;
            border: 1px solid #ccc;
            border-radius: 4px;
            padding: 10px;
            margin-bottom: 10px;
        }

        input[type="file"] {
            margin-bottom: 10px;
        }

        button {
            background-color: #444; /* Dark grey button */
            color: #ffffff; /* White text */
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            width: 100%; /* Full width for buttons */
        }

        button:hover {
            background-color: #555; /* Lighter grey on hover */
        }

        .back-link {
            display: inline-block;
            margin-top: 10px;
            color: #444; /* Dark grey text */
            text-decoration: none;
            font-weight: bold;
        }

        .back-link:hover {
            text-decoration: underline;
            color: #555; /* Lighter grey on hover */
        }
    </style>
<body>
    <h2>Submit Maintenance Report</h2>
    <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="report_id" value="<?= htmlspecialchars($report_id); ?>">

        <label for="work_result">Work Result:</label>
        <textarea name="work_result" id="work_result" required></textarea><br><br>

        <label for="comment">Comment:</label>
        <textarea name="comment" id="comment"></textarea><br><br>

        <label for="image">Upload Image:</label>
        <input type="file" name="image" id="image"><br><br>

        <button type="submit">Submit Report</button>
    </form>

    <?php if ($canMarkResolved): ?>
        <form method="POST" action="mark_as_resolved.php">
            <input type="hidden" name="report_id" value="<?= htmlspecialchars($report_id); ?>">
            <button type="submit">Mark as Resolved</button>
        </form>
    <?php endif; ?>

    <a href="maintenance_dashboard.php">Back to Dashboard</a>
</body>
</html>

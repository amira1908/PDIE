<?php
session_start();
require 'db_connection.php'; // Ensure this file contains your PDO connection
include 'admin_nav.html';

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if the user is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Get the report ID from the URL
$report_id = isset($_GET['report_id']) ? $_GET['report_id'] : null;

if ($report_id === null) {
    die("Report ID is not provided.");
}

// Fetch report details
try {
    $query = "SELECT * FROM reports WHERE id = :report_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':report_id', $report_id, PDO::PARAM_INT);
    $stmt->execute();
    $report = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$report) {
        die("No report found with ID: " . htmlspecialchars($report_id));
    }
} catch (PDOException $e) {
    die("Error fetching report: " . $e->getMessage());
}

// Fetch associated maintenance reports
try {
    $maintenance_query = "SELECT * FROM maintenance_reports WHERE report_id = :report_id";
    $maintenance_stmt = $db->prepare($maintenance_query);
    $maintenance_stmt->bindParam(':report_id', $report_id, PDO::PARAM_INT);
    $maintenance_stmt->execute();
    $maintenance_reports = $maintenance_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching maintenance reports: " . $e->getMessage());
}

// Handle final report creation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['admin_reports'])) {
    // Fetch and sanitize form inputs
    $maintenance_report_id = $_POST['maintenance_report_id'];
    $final_status = $_POST['final_status'];
    $final_report_summary = $_POST['final_report_summary'];
    $admin_id = $_SESSION['user_id']; // Assuming admin ID is stored in the session

    // Debugging output to check form submission
    var_dump($_POST); // Check if the form data is received

    // Ensure final status is one of the allowed values
    if ($final_status !== 'Resolved' && $final_status !== 'Issue') {
        die("Invalid final status selected.");
    }

    // Prepare the SQL query to insert into the admin_reports table
    try {
        $final_report_query = "INSERT INTO admin_reports (admin_id, report_id, maintenance_report_id, final_status, final_report_summary, created_at)
            VALUES (:admin_id, :report_id, :maintenance_report_id, :final_status, :final_report_summary, NOW())";
        
        $final_report_stmt = $db->prepare($final_report_query);
        $final_report_stmt->bindParam(':admin_id', $admin_id, PDO::PARAM_INT);
        $final_report_stmt->bindParam(':report_id', $report_id, PDO::PARAM_INT);
        $final_report_stmt->bindParam(':maintenance_report_id', $maintenance_report_id, PDO::PARAM_INT); // Bind the maintenance report ID
        $final_report_stmt->bindParam(':final_status', $final_status, PDO::PARAM_STR);
        $final_report_stmt->bindParam(':final_report_summary', $final_report_summary, PDO::PARAM_STR);

        if ($final_report_stmt->execute()) {
            // Update the original report status to "Final Report"
            $update_query = "UPDATE reports SET status = 'Final Report' WHERE id = :report_id";
            $update_stmt = $db->prepare($update_query);
            $update_stmt->bindParam(':report_id', $report_id, PDO::PARAM_INT);

            if ($update_stmt->execute()) {
                // Redirect to admin dashboard after successful insertion and update
                header("Location: admin_dashboard.php");
                exit;
            } else {
                echo "Error: Could not update the report status. Please try again.";
            }
        } else {
            echo "Error: Could not save the final report. Please try again.";
        }
    } catch (PDOException $e) {
        die("Error saving final report: " . $e->getMessage());
    }

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Final Report</title>
    <style>
        body {
            font-family: 'Georgia', serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 100px;
            color: #333;
        }

        .container {
            padding: 40px;
            max-width: 800px;
            margin: auto;
            background-color: #ffffff;
            border-radius: 15px;
            box-shadow: 0 6px 25px rgba(0, 0, 0, 0.2);
        }

        h1, h2 {
            text-align: center;
            color: #000000;
        }

        .report-details, .maintenance-reports {
            margin: 20px 0;
            padding: 20px;
            background-color: #f5f5f5;
            border-radius: 10px;
            color: #333;
        }

        .button {
            background-color: #444444;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            margin-top: 10px;
            cursor: pointer;
            border-radius: 5px;
            display: block;
            width: 100%;
        }

        .button:hover {
            background-color: #333333;
        }

        textarea {
            width: 100%;
            height: 200px;
            border-radius: 5px;
            padding: 10px;
            border: 1px solid #cccccc;
            background-color: #ffffff;
            color: #333;
            resize: vertical; /* Allow vertical resize */
        }

        label {
            font-weight: bold;
            color: #000000;
        }

        .center-image {
            display: flex;
            justify-content: center;
            margin-top: 15px;
        }

        .center-image img {
            max-width: 100%;
            max-height: 300px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin-top: 10px;
            margin-bottom: 20px;
        }

        /* Responsive Design */
        @media (max-width: 600px) {
            body {
                padding: 20px;
            }

            .container {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Create Final Report for Report: <br> ID = <?= htmlspecialchars($report['id']) ?> , Title= <?= htmlspecialchars($report['title']) ?></h1>
        
        <div class="report-details">
            <h2>Report Details</h2>
            <?php if (!empty($report['image'])): ?>
                <p><strong>Report Image:</strong></p>
                <div class="center-image">
                    <img src="<?= htmlspecialchars($report['image']) ?>" alt="Report Image">
                </div>
            <?php else: ?>
                <p>No image available for this report.</p>
            <?php endif; ?>
            <p><strong>Title:</strong> <?= htmlspecialchars($report['title']) ?></p>
            <p><strong>Description:</strong> <?= htmlspecialchars($report['description']) ?></p>
            <p><strong>Facility Type:</strong> <?= htmlspecialchars($report['facility_type']) ?></p>
            <p><strong>Location:</strong> <?= htmlspecialchars($report['location']) ?></p>
            <p><strong>Status:</strong> <?= htmlspecialchars($report['status']) ?></p>
            <p><strong>Created At:</strong> <?= htmlspecialchars($report['created_at']) ?></p>
            <p><strong>Assigned To:</strong> <?= htmlspecialchars($report['assigned_to']) ?></p>
        </div>

        <div class="maintenance-reports">
            <h2>Associated Maintenance Reports</h2>
            <?php if (count($maintenance_reports) > 0) { ?>
                <?php foreach ($maintenance_reports as $maintenance_report) { ?>
                    <?php if (!empty($maintenance_report['image'])): ?>
                        <p><strong>Maintenance Report Image:</strong></p>
                        <div class="center-image">
                            <img src="<?= htmlspecialchars($maintenance_report['image']) ?>" alt="Maintenance Image">
                        </div>
                    <?php else: ?>
                        <p>No image available for this report.</p>
                    <?php endif; ?>
                    <p><strong>Maintenance ID:</strong> <?= htmlspecialchars($maintenance_report['id']) ?></p>
                    <p><strong>Details:</strong> <?= htmlspecialchars($maintenance_report['work_result']) ?></p>
                    <p><strong>Maintenance Team Comment:</strong> <?= htmlspecialchars($maintenance_report['comment']) ?></p>
                    <p><strong>Created At:</strong> <?= htmlspecialchars($maintenance_report['created_at']) ?></p>
                <?php } ?>
            <?php } else { ?>
                <p>No associated maintenance reports found.</p>
            <?php } ?>
        </div>

        <form method="POST">
            <input type="hidden" name="maintenance_report_id" value="<?= htmlspecialchars($maintenance_reports[0]['id']) ?>">
            <label for="final_status">Final Status:</label>
            <select id="final_status" name="final_status" required>
                <option value="">--Select Status--</option>
                <option value="Resolved">Resolved</option>
                <option value="Issue">Has Issue</option>
            </select><br><br>

            <label for="final_report_summary">Final Report Summary:</label>
            <textarea name="final_report_summary" id="final_report_summary" required></textarea>
            
            <button type="submit" name="admin_reports" class="button">Submit Final Report</button>
        </form>
    </div>
</body>
</html>

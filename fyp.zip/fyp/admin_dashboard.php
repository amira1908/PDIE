<?php
session_start();
require 'db_connection.php'; // Ensure this file contains your PDO connection
include 'admin_nav.html';

// Check if the user is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Prepare and execute queries to count reports by status
$statuses = [
    'unassigned' => 'SELECT COUNT(*) AS count FROM reports WHERE status = "pending"',
    'assigned' => 'SELECT COUNT(*) AS count FROM reports WHERE status = "assigned"',
    'accepted' => 'SELECT COUNT(*) AS count FROM reports WHERE status = "accepted"', // Fixed typo here
    'resolved' => 'SELECT COUNT(*) AS count FROM reports WHERE status = "resolved"',
    'in_progress' => 'SELECT COUNT(*) AS count FROM reports WHERE status = "in progress"',
    'final_report' => 'SELECT COUNT(*) AS count FROM reports WHERE status = "final report"',
    'issue' => 'SELECT COUNT(*) AS count FROM reports WHERE status = "issue"',
];

// Initialize counts
$counts = [];

// Execute each query and store the results
foreach ($statuses as $key => $query) {
    $stmt = $db->prepare($query);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $counts[$key] = $result['count'];
}

// Count all reports
$total_query = "SELECT COUNT(*) AS total_count FROM reports";
$total_stmt = $db->prepare($total_query);
$total_stmt->execute();
$total_result = $total_stmt->fetch(PDO::FETCH_ASSOC);
$total_count = $total_result['total_count'];

// Fetch the latest reports for display
$latest_reports_query = "SELECT * FROM reports ORDER BY created_at DESC LIMIT 5";
$latest_reports_stmt = $db->prepare($latest_reports_query);
$latest_reports_stmt->execute();
$latest_reports = $latest_reports_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* General Body Styles */
        body {
            font-family: 'Arial', sans-serif; /* Modern font */
            background-color: #f0f0f0; /* Light grey background */
            margin: 0;
            padding: 100px; /* Tight layout */
            display: flex;
            justify-content: center;
            align-items: flex-start;
            min-height: 100vh;
            color: #333; /* Dark grey text color */
        }

        /* Container Styles */
        .container {
            background-color: #ffffff; /* White container background */
            padding: 30px; /* Adjusted padding */
            border-radius: 10px; /* Slightly less round */
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3); /* Slightly darker shadow */
            max-width: 800px;
            width: 100%;
            border: 1px solid #cccccc; /* Darker grey border */
        }

        /* Header Styles */
        h2, h3 {
            color: #333; /* Darker grey for better contrast */
            text-align: center;
            font-size: 26px; /* Adjusted font size */
            letter-spacing: 0.5px;
            margin-bottom: 15px; /* Added margin for spacing */
        }

        p {
            text-align: center;
            font-size: 16px; /* Smaller font size for p */
            color: #555; /* Medium grey */
            margin-bottom: 20px;
        }

        /* Chart Container */
        .chart-container {
            margin-bottom: 30px; /* Space below the chart */
        }

        /* Summary Cards Section */
        .summary-cards {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
            flex-wrap: wrap;
        }

        /* Card Styles */
        .card {
            background-color: #f0f0f0; /* Light grey for card background */
            padding: 15px;
            border-radius: 8px;
            width: calc(20% - 10px);
            margin: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2); /* Slightly darker shadow */
            cursor: pointer;
            transition: background-color 0.3s, transform 0.3s; /* Added transform effect */
        }

        .card:hover {
            background-color: #d0d0d0; /* Darker grey on hover */
            transform: translateY(-2px); /* Slight lift effect */
        }

        .card h3 {
            font-size: 22px;
            margin-bottom: 5px;
            color: #333; /* Darker text for card titles */
        }

        .card p {
            font-size: 16px;
            margin: 0;
            color: #444; /* Darker medium grey */
        }

        /* Latest Reports Section */
        .latest-reports {
            margin-top: 20px;
        }

        .latest-reports h3 {
            margin-bottom: 10px;
        }

        /* Table Styles */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th, td {
            border: 1px solid #cccccc; /* Darker grey for table borders */
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #444; /* Dark grey for header */
            color: #ffffff; /* White text */
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .summary-cards {
                flex-direction: column;
                align-items: center;
            }

            .card {
                width: 90%; /* Wider cards on small screens */
                margin: 10px 0; /* Vertical spacing for small screens */
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Admin Dashboard</h2>
        <p>Welcome to the admin dashboard!</p>
        
        <!-- Chart Section -->
        <div class="chart-container">
            <canvas id="reportChart"></canvas>
        </div>

        <h3>Total Reports: <?= htmlspecialchars($total_count) ?></h3>
        
        <!-- Summary Cards Section -->
        <div class="summary-cards">
            <div class="card" onclick="window.location.href='admin_report_list.php?status=pending'">
                <h3>Unassigned Reports</h3>
                <p><?= htmlspecialchars($counts['unassigned']) ?></p>
            </div>
            <div class="card" onclick="window.location.href='admin_report_list.php?status=assigned'">
                <h3>Assigned Reports</h3>
                <p><?= htmlspecialchars($counts['assigned']) ?></p>
            </div>
            <div class="card" onclick="window.location.href='admin_report_list.php?status=accepted'">
                <h3>Accepted Reports</h3>
                <p><?= htmlspecialchars($counts['accepted']) ?></p> <!-- Fixed key here -->
            </div>
            <div class="card" onclick="window.location.href='admin_report_list.php?status=in progress'">
                <h3>In-Progress Reports</h3>
                <p><?= htmlspecialchars($counts['in_progress']) ?></p>
            </div>
            <div class="card" onclick="window.location.href='admin_report_list.php?status=issue'">
                <h3>Problem Occur Reports</h3>
                <p><?= htmlspecialchars($counts['issue']) ?></p>
            </div>
            <div class="card" onclick="window.location.href='admin_report_list.php?status=resolved'">
                <h3>Resolved Reports</h3>
                <p><?= htmlspecialchars($counts['resolved']) ?></p>
            </div>
            <div class="card" onclick="window.location.href='admin_report_list.php?status=final report'">
                <h3>Final Reports</h3>
                <p><?= htmlspecialchars($counts['final_report']) ?></p>
            </div>
        </div>

        <!-- Latest Reports Section -->
        <div class="latest-reports">
            <h3>Latest Reports</h3>
            <table>
                <thead>
                    <tr>
                        <th>Report ID</th>
                        <th>Status</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($latest_reports as $report): ?>
                        <tr>
                            <td><?= htmlspecialchars($report['id']) ?></td>
                            <td><?= htmlspecialchars($report['status']) ?></td>
                            <td><?= htmlspecialchars($report['created_at']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        const ctx = document.getElementById('reportChart').getContext('2d');
        const reportChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Unassigned', 'Assigned', 'Accepted', 'In Progress', 'Resolved', 'Final Reports', 'Issues'],
                datasets: [{
                    label: 'Report Count',
                    data: [
                        <?= htmlspecialchars($counts['unassigned']) ?>,
                        <?= htmlspecialchars($counts['assigned']) ?>,
                        <?= htmlspecialchars($counts['accepted']) ?>,
                        <?= htmlspecialchars($counts['in_progress']) ?>,
                        <?= htmlspecialchars($counts['resolved']) ?>,
                        <?= htmlspecialchars($counts['final_report']) ?>,
                        <?= htmlspecialchars($counts['issue']) ?>
                    ],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)', // Unassigned
                        'rgba(54, 162, 235, 0.2)', // Assigned
                        'rgba(255, 206, 86, 0.2)', // Accepted
                        'rgba(75, 192, 192, 0.2)', // In Progress
                        'rgba(153, 102, 255, 0.2)', // Resolved
                        'rgba(255, 159, 64, 0.2)', // Final Reports
                        'rgba(255, 99, 132, 0.2)'  // Issues
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)', // Unassigned
                        'rgba(54, 162, 235, 1)', // Assigned
                        'rgba(255, 206, 86, 1)', // Accepted
                        'rgba(75, 192, 192, 1)', // In Progress
                        'rgba(153, 102, 255, 1)', // Resolved
                        'rgba(255, 159, 64, 1)', // Final Reports
                        'rgba(255, 99, 132, 1)'  // Issues
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>

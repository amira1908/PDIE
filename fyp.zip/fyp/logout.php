<?php
session_start();
session_destroy(); // Destroy the session to log out the user

// Redirect to the login page
header("Location: login.php");
exit;

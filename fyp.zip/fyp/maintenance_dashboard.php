<?php
session_start();
require 'db_connection.php';
include 'maintenance_nav.html';

// Check if user is logged in and is part of the maintenance team
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'maintenance_team') {
    header("Location: login.php");
    exit;
}

// Get the maintenance team member's ID
$staff_id = $_SESSION['user_id'];

// Fetch reports assigned to the maintenance team member
$query = "SELECT r.*, 
                 (SELECT COUNT(*) FROM maintenance_reports mr WHERE mr.report_id = r.id) AS has_maintenance_report 
          FROM reports r 
          WHERE r.assigned_to = ? AND r.status != 'Resolved'";
$stmt = $db->prepare($query);
$stmt->execute([$staff_id]);
$reports = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maintenance Team Dashboard</title>
    <style>
    /* General Body Styles */
    body {
        font-family: Arial, sans-serif; /* Clean, sans-serif typography */
        background-color: lightgrey; /* Light grey background for subtle contrast */
        margin: 0;
        padding: 20px;
        color: #333; /* Dark grey for main text */
    }

    /* Header Styles */
    h2 {
        text-align: center;
        color: #333; /* Dark grey for the header */
        font-size: 24px;
        margin-bottom: 20px;
        letter-spacing: 0.5px;
    }

    /* Table Styles */
    table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
        background-color: #ffffff; /* White background for table */
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); /* Soft shadow for depth */
        border: 1px solid #cccccc; /* Light grey border */
    }

    th, td {
        padding: 12px;
        text-align: left;
        color: #333; /* Dark grey for cell text */
    }

    /* Header Row Styles */
    th {
        background-color: #555; /* Darker grey for header */
        color: #ffffff; /* White text for contrast */
        font-weight: bold;
        text-transform: uppercase;
        font-size: 14px;
    }

    /* Row Alternating Color and Hover Effect */
    tr:nth-child(even) {
        background-color: #f9f9f9; /* Light grey for alternate rows */
    }

    tr:hover {
        background-color: #e0e0e0; /* Slightly darker grey on hover */
    }

    /* Link Styles */
    a {
        color: #555; /* Dark grey for links */
        text-decoration: none;
        font-weight: bold;
    }

    a:hover {
        text-decoration: underline;
        color: #333; /* Darker grey on hover */
    }
</style>

</head>
<body>

    <h2>Assigned Facility Reports</h2>

    <table>
        <thead>
            <tr>
                <th>Report ID</th>
                <th>Title</th>
                <th>Facility Type</th>
                <th>Status</th>
                <th>Action</th>
                <th>Maintenance Report</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($reports as $report): ?>
                <tr>
                    <td data-label="Id"><?= htmlspecialchars($report['id']); ?></td>
                    <td data-label="Title"><?= htmlspecialchars($report['title']); ?></td>
                    <td data-label="Facility Type"><?= htmlspecialchars($report['facility_type']); ?></td>
                    <td data-label="Status"><?= htmlspecialchars($report['status']); ?></td>
                    <td data-label="Action">
                        <a href="maintenance_update_report.php?report_id=<?= htmlspecialchars($report['id']); ?>">View & Update</a>
                    </td>
                    <td data-label="Maintenance Report">
                        <?php if ($report['status'] === 'Accepted' || $report['status'] === 'Assigned'): ?>
                            N/A
                        <?php elseif ($report['has_maintenance_report'] > 0): ?>
                            Report Submitted
                        <?php else: ?>
                            <a href="maintenance_submit_report.php?report_id=<?= htmlspecialchars($report['id']); ?>">Create Maintenance Report</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

</body>
</html>

<?php
$servername = "localhost"; // Correct variable name
$username = "root";         // Your database username
$password = "";             // Your database password (leave empty if no password)
$dbname = "facility_report_system"; // Your database name

try {
    // Use $servername instead of $host
    $db = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage()); // Stop and display "Connection failed: "
}

?>

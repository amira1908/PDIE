<?php
session_start();
require 'db_connection.php';
include 'applicant_nav.html';

// Ensure user is logged in and is an applicant
if (!isset($_SESSION['user_id']) ||  ($_SESSION['role'] !== 'applicant' && $_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'maintenance_team')) {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['report_id'])) {
    header("Location: applicant_report_history.php");
    exit;
}

$report_id = $_GET['report_id'];
$applicant_id = $_SESSION['user_id'];

// Fetch the report details
$stmt = $db->prepare"SELECT * FROM reports WHERE assigned_to = :user_id AND status IN ('Resolved', 'Final Report')";
$stmt->execute([$report_id, $applicant_id]);
$report = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$report) {
    header("Location: applicant_report_history.php");
    exit;
}

$feedback_message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $feedback = $_POST['feedback'];

    // Insert feedback into the feedback table
    $feedback_stmt = $db->prepare("INSERT INTO feedback (report_id, applicant_id, feedback, created_at) VALUES (?, ?, ?, NOW())");
    $feedback_stmt->execute([$report_id, $applicant_id, $feedback]);

    $feedback_message = "Thank you for your feedback!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Details</title>
    <link rel="navbar" href="applicant_nav.html">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f0f0; /* Light grey background */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #ffffff; /* White background for the container */
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2); /* Darker shadow */
            max-width: 600px;
            width: 100%;
        }

        h1 {
            color: #333; /* Dark grey for the heading */
            text-align: center;
            margin-bottom: 20px;
            font-size: 35px;
        }

        p {
            font-size: 20px;
            color: #555; /* Medium grey for paragraph text */
            margin-bottom: 10px;
        }

        strong {
            font-weight: 600;
        }

        h3 {
            color: #333; /* Dark grey for subheadings */
            font-size: 20px;
            margin-top: 30px;
            text-align: center;
        }

        textarea {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc; /* Light grey border */
            margin-top: 10px;
            font-size: 16px;
        }

        input[type="submit"] {
            background-color: #333; /* Dark grey button */
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
            margin-top: 10px;
            width: 100%;
        }

        input[type="submit"]:hover {
            background-color: #555; /* Lighter grey on hover */
        }

        .feedback-message {
            color: green;
            text-align: center;
            margin-bottom: 20px;
        }

        .back-link {
            display: block;
            text-align: left;
            margin-top: 20px;
            color: grey; /* Grey color for back link */
            text-decoration: none;
        }

        .back-link:hover {
            text-decoration: underline; /* Underline on hover */
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Back to report history button -->
        <a href="applicant_report_history.php" class="back-link"><-Back to Report History</a>
        <h1>Report Details</h1>

        <p><strong>Title:</strong> <?= htmlspecialchars($report['title']) ?></p>
        <p><strong>Description:</strong> <?= htmlspecialchars($report['description']) ?></p>
        <p><strong>Facility Type:</strong> <?= htmlspecialchars($report['facility_type']) ?></p>
        <p><strong>Location:</strong> <?= htmlspecialchars($report['location']) ?></p>
        <p><strong>Submitted On:</strong> <?= $report['created_at'] ?></p>
        <p><strong>Status:</strong> <?= $report['status'] ?></p>

        <!-- Feedback form -->
        <?php if ($feedback_message): ?>
            <p class="feedback-message"><?= $feedback_message ?></p>
        <?php else: ?>
            <h3>Submit Feedback</h3>
            <form action="report_detail.php?report_id=<?= $report['id'] ?>" method="POST">
                
                <textarea name="feedback" rows="4" placeholder="Write your feedback..." required></textarea><br>
                <input type="submit" value="Submit Feedback">
            </form>
        <?php endif; ?>

        
    </div>
</body>
</html>
